import Widget from './components/App'

document.addEventListener('DOMContentLoaded', () => {
	const app = new Widget('#app')
})
